from setuptools import setup

setup(
	name='dexonlineBK',
	version='0.0.6',
	description='Small dexonline.ro API for Python',
	author='Alexandru Petrachi (BlackKakapo)',
	packages=['dexonlineBK'],
	zip_safe=False
)